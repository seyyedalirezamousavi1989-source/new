# LocalChat 1.9.4 startup hotfix

Fixed a startup version mismatch: `server.py` reported 1.9.4 while `launcher.py` still expected 1.9.2. The launcher therefore timed out while polling `/api/status` and displayed that the chat server had not started, even when it was running. Both versions now match. Added a regression test for version parity. No STT, microphone, or TTS inference behavior changed in this hotfix.
