# LocalChat 2.0.0 — Windows Toolchain Fix 3

This update addresses the remaining Windows toolchain regression reports:

- Corrected the Windows-only Flutter and VS Code test shims to write real CRLF-delimited `.cmd` files. The previous fixtures accidentally wrote literal `\\r\\n` text, so `cmd.exe` could not parse the fake commands reliably.
- On Windows, Node/npm tasks now prefer `node.exe <npm-cli.js> ...` when the npm CLI script is available beside the discovered npm command. This bypasses `.cmd` launcher quoting/PATHEXT differences. If the CLI script cannot be located, LocalChat safely falls back to the discovered npm executable and the existing `.cmd` process wrapper.
- Existing allow-lists, approval flow, script-install restrictions, and command timeouts remain in place.

Validation in the build environment:

- `python -m compileall -q local_chat` — passed.
- `python -m pytest -q local_chat/test_programming_stacks.py` — 11 passed.
- `python -m pytest -q local_chat/test_programming_e2e.py local_chat/test_programming_quality.py local_chat/test_programming_stacks.py` — 82 passed, 1 skipped.

The complete suite did not finish within the available execution window. This build has not been run on the user's Windows machine; the Windows-specific `.cmd` branch and real Node/npm integration still require confirmation there.
