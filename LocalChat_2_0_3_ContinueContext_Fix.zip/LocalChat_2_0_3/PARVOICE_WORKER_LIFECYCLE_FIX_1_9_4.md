# LocalChat 1.9.4 – ParsVoice Worker Lifecycle Fix

## Changes
- Added TTS worker protocol version 3 and health metadata for the requested and resolved ParsVoice model directory.
- The server no longer accepts a legacy worker just because `/health` responds. It checks the engine, protocol version, and configured model path.
- A TTS worker is stopped after every TTS settings save so the next synthesis launches it with the latest settings.
- When an incompatible worker occupies port 8775, the server attempts to stop only a process whose command line identifies it as this application's `tts_worker.py` (psutil where available, PowerShell/CIM on Windows otherwise). It never terminates an unrelated process merely because it owns the port.
- If safe termination is not possible, the UI receives a clear stale-worker diagnostic instead of silently using the old worker.
- Worker `/health` now reports protocol version, requested model path, resolved model path, and whether required model files are present.
- STT worker, microphone capture, and STT endpoints were not modified.

## Validation
- `python -m py_compile local_chat/server.py local_chat/tts_worker.py`
- `pytest -q local_chat/test_audio_integration.py local_chat/test_settings.py`
- Result: 17 passed.

## Notes
The package has not been executed on the user's Windows machine. The next run should show worker protocol/path metadata in `%LOCALAPPDATA%\\LocalChat\\voice\\tts_worker.log` and the server console.
