# LocalChat 1.9.7 – ParsVoice browser playback diagnostics and compatibility

## Findings from the supplied 2026-11-08 logs

The ParsVoice worker returned successful HTTP 200 responses for `/api/voice/synthesize` at 05:12:37, 05:13:11, 05:14:13, and 05:14:41. The earlier model-directory `FileNotFoundError` entries precede those successful requests. The remaining reported browser error therefore occurs after synthesis, during response validation or playback.

## Changes

- Validate generated WAV payloads in the worker before returning HTTP 200: RIFF/WAVE readability, PCM compression, channel count, sample width, sample rate, frame count, and payload length.
- Validate the browser response's WAV signature and non-empty body before playback, with actionable diagnostics for invalid responses.
- Keep normal HTMLAudio playback as the primary path and add WebAudio decode/playback fallback for Chromium environments where HTMLAudio rejects an otherwise valid WAV Blob.
- Keep microphone capture and STT request paths unchanged.

## Validation

- Python compilation: passed.
- `node --check local_chat/static/app.js`: passed.
- `pytest -q local_chat/test_audio_integration.py local_chat/test_settings.py`: 22 passed.

The local tests validate WAV structure and application code paths; they do not claim to reproduce the user's Windows browser/device playback environment.
