# اصلاح واقعی خطای COLLECT (محدودیت ۲۶۰ کاراکتر مسیر ویندوز)

علت: مسیر مقصد فایل `numpy.libs\libopenblas64__...dll` حدود ۲۷۱ کاراکتر بود (بیش از MAX_PATH=260). به همین دلیل `open(dst,'wb')` با وجود موجود بودن پوشه، `FileNotFoundError` می‌داد؛ پس retry هم بی‌اثر بود.

اصلاح‌ها:
- هر دو فایل spec: کپی با مسیر extended-length (`\\?\`) برای `copyfile` و `copystat`.
- `build_installer.bat`: ساخت payload در پوشهٔ کوتاه `%LOCALAPPDATA%\LCB` و ارسال مسیر آن به Inno با `/DPayloadDir`.
- `installer.iss`: مسیر payload قابل تنظیم (پیش‌فرض قبلی حفظ شد).
- توصیه: پوشهٔ پروژه را هم کوتاه‌تر کنید (مثلاً `G:\LC`).
