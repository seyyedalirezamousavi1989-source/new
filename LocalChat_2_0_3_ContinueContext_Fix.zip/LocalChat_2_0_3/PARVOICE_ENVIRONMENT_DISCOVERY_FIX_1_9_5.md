# LocalChat 1.9.5 – ParsVoice environment discovery fix

The screenshot error came from `_voice_python()` failing to find a Python interpreter that can import `TTS`. The previous discovery only checked the AppData environment, the extracted app folder, and the current interpreter.

This release also checks the user's existing `G:\agentgptversion\.venv-parsvoice` installation, honors `AIRESEARCH_TTS_PYTHON`, de-duplicates candidates, and reports every checked interpreter path when no working environment is found. Launcher and server versions are kept in sync at 1.9.5. STT and microphone code are unchanged.

If the known environment is not present on another machine, run `setup/audio/setup_voice.ps1` or set `AIRESEARCH_TTS_PYTHON` to the full path of the ParsVoice environment's `python.exe`.
