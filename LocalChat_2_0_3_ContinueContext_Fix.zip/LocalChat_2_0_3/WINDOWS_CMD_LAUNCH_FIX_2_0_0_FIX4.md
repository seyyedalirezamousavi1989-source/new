# LocalChat 2.0.0 — Windows batch launcher fix (Fix 4)

## Changes
- Corrected Windows `.bat` / `.cmd` launching in `local_chat/procutil.py`.
- `cmd.exe` is now invoked using a single explicitly constructed command-line string. The previous list-based invocation caused Python to quote the embedded `/c` command a second time, which could make Windows `cmd.exe` parse the script path incorrectly.
- This shared path is used by Flutter's `flutter.cmd` and VS Code's `code.cmd`, addressing the two remaining failures reported by the Windows regression run.

## Validation performed in the build environment
- `python -m compileall -q local_chat` — passed.
- `python -m pytest -q local_chat/test_programming_stacks.py local_chat/test_programming_e2e.py local_chat/test_programming_quality.py --disable-warnings --maxfail=5` — 82 passed, 1 skipped.

The build environment is not Windows, so actual `cmd.exe` execution and the full Windows installer build still require validation on a Windows machine.
