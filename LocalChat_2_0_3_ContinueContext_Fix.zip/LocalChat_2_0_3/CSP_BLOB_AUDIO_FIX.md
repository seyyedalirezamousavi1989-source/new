# CSP blob audio playback fix

The audio player creates an object URL with `URL.createObjectURL(blob)` and assigns it to `new Audio(...)`.
The server Content-Security-Policy previously omitted `media-src`, so Chromium applied `default-src 'self'` and blocked `blob:` media URLs.

The policy now explicitly includes `media-src 'self' blob:`. This permits locally served media and audio Blob URLs while leaving script, style, image, connect, font, and other CSP restrictions unchanged.

No microphone, recording, STT, or transcription code was changed.
