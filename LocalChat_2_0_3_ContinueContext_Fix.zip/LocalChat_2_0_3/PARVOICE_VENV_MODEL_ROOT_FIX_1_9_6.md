# LocalChat 1.9.6 – ParsVoice model root discovery

## Root cause
The 1.9.5 worker searched the extracted LocalChat directory and AppData, but did not search the repository root that contains the dedicated ParsVoice virtual environment. The user's known layout places the environment at `G:\agentgptversion\.venv-parsvoice` and the model at `G:\agentgptversion\models\ParsVoice-XTTS`.

## Fix
The worker now derives the repository root from the Python interpreter running it. When that interpreter is inside `.venv-parsvoice`, it also checks the sibling `models\ParsVoice-XTTS` and `models\parsvoice-xtts-v2` directories. It still validates that both `config.json` and `model.pth` exist and retains the configured, AppData, app-local, and Hugging Face cache candidates. The virtual environment itself is never mistaken for the model directory.

## Regression checks
Added a test reproducing the user's separate app/venv/model directory layout. Audio integration and settings tests: 20 passed.

STT worker and microphone code were not changed.
