# ParsVoice model path resolution fix

This update addresses the `FileNotFoundError` reported when the ParsVoice worker
looked only in `%LOCALAPPDATA%\\LocalChat\\voice\\models\\ParsVoice-XTTS`.

The worker now checks, in order:
- The model folder configured in LocalChat audio settings (`model_dir`).
- The standard LocalChat AppData model folder.
- `models\\ParsVoice-XTTS` and `models\\parsvoice-xtts-v2` beside the application.
- The Hugging Face cache folder for `MohammadJRanjbar/parsvoice-xtts-v2`.
- One- and two-level nested model folders (including extracted/snapshot layouts).

A valid model directory must contain both `config.json` and `model.pth` in the
same directory. No model is downloaded, moved, or overwritten. If no valid folder
is found, the error lists the locations checked and explains what folder to set
in Audio Settings.

The TTS HTTP error handler now preserves the worker's JSON error body, and the
worker writes a traceback to `tts_worker.log` for future diagnosis.

STT worker, microphone capture, and transcription code were not modified.
